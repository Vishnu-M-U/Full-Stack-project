package com.example.hrtaskfinal.emsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
